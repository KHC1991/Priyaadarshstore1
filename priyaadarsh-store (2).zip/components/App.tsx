
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import Intro from './Intro';
import LandingPage from './LandingPage';
import Auth from './Auth';
import Dashboard from './Dashboard';
import { User, Language } from '../types';

const AppContent = () => {
  const [showIntro, setShowIntro] = useState(true);
  const [introFade, setIntroFade] = useState(false);
  const [language, setLanguage] = useState<Language>('gu'); // Default to Gujarati as requested
  const [user, setUser] = useState<User | null>(null);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const timer = setTimeout(() => {
      setIntroFade(true);
      setTimeout(() => {
        setShowIntro(false);
        const params = new URLSearchParams(location.search);
        const ref = params.get('ref');
        if (ref) {
          navigate('/register' + location.search);
        }
      }, 800); 
    }, 4000);
    return () => clearTimeout(timer);
  }, [navigate, location.search]);

  return (
    <>
      {showIntro && (
        <div className={`transition-opacity duration-700 ${introFade ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}>
          <Intro />
        </div>
      )}
      
      <div className={showIntro ? 'hidden' : 'block'}>
        <Routes>
          <Route path="/" element={<LandingPage language={language} setLanguage={setLanguage} />} />
          <Route path="/login" element={<Auth mode="login" language={language} setLanguage={setLanguage} onAuth={setUser} />} />
          <Route path="/register" element={<Auth mode="register" language={language} setLanguage={setLanguage} onAuth={setUser} />} />
          <Route path="/dashboard/*" element={user ? <Dashboard user={user} setUser={setUser} language={language} setLanguage={setLanguage} /> : <Auth mode="login" language={language} setLanguage={setLanguage} onAuth={setUser} />} />
        </Routes>
      </div>
    </>
  );
};

const App = () => (
  <HashRouter>
    <AppContent />
  </HashRouter>
);

export default App;
